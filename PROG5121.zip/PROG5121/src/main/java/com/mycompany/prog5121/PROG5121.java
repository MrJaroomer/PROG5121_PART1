package com.mycompany.prog5121;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

// Class to bundle user data
public class PROG5121 {
    
    public static class User {
    public String username;
    public String password;
    public String phoneNumber;

    public User(String username, String password, String phoneNumber) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }
}
    public static ArrayList<User> userList = new ArrayList<>();
    public static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("---User Authentication---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                register();
            } else if (choice.equals("2")) {
                login();
            } else if (choice.equals("3")) {
                break;
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    public static void register() {
        String username = "";
        boolean isUsernameValid = false;

        // Username Validation
        while (!isUsernameValid) {
            System.out.print("Enter username: ");
            username = scanner.nextLine();

            // Check if username has an underscore and is 5 chars or less
            boolean meetsRequirements = username.contains("_") && username.length() <= 5;
            if (!meetsRequirements) {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
                continue; 
            }

            // Check if the username is already taken by searching through our list
            boolean alreadyExists = false;
            for (User u : userList) {
                if (u.username.equals(username)) {
                    alreadyExists = true;
                    break;
                }
            }

            if (alreadyExists) {
                System.out.println("Error: User already exists! Try another.");
            } else {
                isUsernameValid = true; 
                System.out.println("Username successfully captured.");
            }
        }

        // Password Complexity
        String pass = "";
        boolean isPasswordValid = false;
        while (!isPasswordValid) {
            System.out.print("Enter password: ");
            pass = scanner.nextLine();

            boolean hasLength = pass.length() >= 8;
            boolean hasUpper = false;
            boolean hasDigit = false;
            boolean hasSpecial = false;
            String specialChars = "!@#$%^&*()-_=+[]{}|;:',.<>/?";

            // Loop through each character of the password to check for specific types
            for (char c : pass.toCharArray()) {
                if (Character.isUpperCase(c)) hasUpper = true;
                if (Character.isDigit(c)) hasDigit = true;
                if (specialChars.contains(String.valueOf(c))) hasSpecial = true;
            }

            if (hasLength && hasUpper && hasDigit && hasSpecial) {
                isPasswordValid = true;
                System.out.println("Password successfully captured.");
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        // Phonenumber (Cleans spaces/dashes, shows +27, takes 9 digits)
        String fullPhone = "";
        boolean isPhoneValid = false;
        // Starts with 6-8, followed by exactly 8 digits
        String saSuffixRegex = "^[6-8][0-9]{8}$";

        while (!isPhoneValid) {
            System.out.print("Enter SA cellphone number: +27 "); 
            // Removes all spaces and dashes automatically
            String suffix = scanner.nextLine().trim().replaceAll("[\\s-]", "");

            if (!Pattern.matches(saSuffixRegex, suffix)) {
                System.out.println("Cell phone number incorrectly formatted.");
                continue;
            }

            fullPhone = "+27" + suffix;

            // Check if this specific phone number is already registered
            boolean phoneInUse = false;
            for (User u : userList) {
                if (u.phoneNumber.equals(fullPhone)) {
                    phoneInUse = true;
                    break;
                }
            }

            if (phoneInUse) {
                System.out.println("Error: This phone number is already registered to another account.");
            } else {
                isPhoneValid = true;
                System.out.println("Cell phone number +27 " + suffix + " has been successfully added.");
            }
        }
        
        // Save the new user object into the list
        userList.add(new User(username, pass, fullPhone)); 
        System.out.println("Registration complete! All data stored.");
    }

    public static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String pass = scanner.nextLine();

        // Search the list for a User object that matches both username and password
        for (User u : userList) {
            if (u.username.equals(username) && u.password.equals(pass)) {
                System.out.println("Welcome " + username + ", it is great to see you again.");
                return;
            }
        }
        
        System.out.println("Username or password incorrect, please try again.");
    }
}
