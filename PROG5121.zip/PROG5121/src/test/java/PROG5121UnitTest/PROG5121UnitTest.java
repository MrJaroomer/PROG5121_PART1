/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package PROG5121UnitTest;

import com.mycompany.prog5121.PROG5121;
import com.mycompany.prog5121.PROG5121.User;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author MrJaroo
 */
public class PROG5121UnitTest {
    
    @Test
public void testUserCreation() {
        User user = new User("john_doe", "Pass123!", "+27123456789");
        assertEquals("john_doe", user.username);
        assertEquals("Pass123!", user.password);
        assertEquals("+27123456789", user.phoneNumber);
}
}
